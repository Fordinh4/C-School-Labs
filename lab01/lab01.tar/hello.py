import sys

def main():
	
	print("Nice to meet you CMPUT 201!")

main()
