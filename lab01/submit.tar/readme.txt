vim ls_com.txt
ls -lh ~ > ls_out.txt
gcc -Wall -std=c99 hello.c -o hello
./hello
tar -cf submit.tar check ls_com.txt ls_out.txt hello.c readme.txt
