
#include <stdio.h>

int main() {

	printf("Nice to meet you CMPUT 201!\n");
	return 0;
}
